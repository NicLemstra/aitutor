import streamlit as st

st.set_page_config(page_title='AI Tutor')
st.title('✅ Hello from the AI Tutor App!')
st.write('If you are seeing this, everything is working correctly.')
