# AI Tutor App

This is a minimal working Streamlit app to help debug deployment errors.